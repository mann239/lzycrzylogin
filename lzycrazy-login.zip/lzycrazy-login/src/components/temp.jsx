import React, { useState } from 'react';
import logo from '../assets/lzycrazy-logo.png';
// import './LoginForm.css'; // If you want component-scoped styles

const LoginForm = () => {
    const [formData, setFormData] = useState({ email: '', password: '' });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleLogin = (e) => {
        e.preventDefault();
        alert(`Email: ${formData.email}\nPassword: ${formData.password}`);
        // You can integrate API call here
    };

    return (
        <div className="login-page container-fluid d-flex flex-wrap justify-content-around align-items-center py-5">
            <div className="left-section mb-5">
                <img src={logo} alt="LzyCrazy Logo" className="logo" />                
                <input type="text" className="form-control search-box mb-3" placeholder="🔍 Search here..." />
                <div className="button-group">
                    {['About Us', 'LzyCrazy Services', 'LzyCrazy Marketplace', 'We Are Hiring', 'LzyCrazy News'].map((text, index) => (
                        <button key={index} className="btn btn-light rounded-pill shadow-sm m-1 px-3">{text}</button>
                    ))}
                </div>
            </div>

            <div className="card login-card p-4">
                <form onSubmit={handleLogin}>
                    <div className="form-group mb-3">
                        <input type="email" name="email" placeholder="Email Address" className="form-control" onChange={handleChange} required />
                    </div>
                    <div className="form-group mb-2">
                        <input type="password" name="password" placeholder="Password" className="form-control" onChange={handleChange} required />
                    </div>
                    <div className="text-end mb-3">
                        <button
                            type="button"
                            className="btn btn-link text-decoration-none small text-primary p-0"
                            onClick={() => alert("Forgot password flow coming soon!")}>
                            Forgot Password?
                        </button>
                    </div>

                    <button type="submit" className="btn w-100 text-white login-btn mb-3">Login</button>

                    <div className="text-center my-2 text-muted">or continue with</div>

                    <div className="d-flex justify-content-between mb-3">
                        <button className="btn btn-outline-dark w-50 me-3 d-flex align-items-center justify-content-center shadow-sm">
                            <img src="https://img.icons8.com/color/20/000000/google-logo.png" alt="Google" className="me-2" />
                            Google
                        </button>
                        <button className="btn btn-outlinedark w-50 d-flex align-items-center justify-content-center shadow-sm">
                            <img src="https://img.icons8.com/fluency/20/facebook-new.png" alt="Facebook" className="me-2" />
                            Facebook
                        </button>
                    </div>

                    <button className="btn text-white create-btn btncenter">Create New Account</button>
                </form>
            </div>
        </div>
    );
};

export default LoginForm;
