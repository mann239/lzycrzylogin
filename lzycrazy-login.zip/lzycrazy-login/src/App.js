// src/App.js
import React from 'react';
import LoginForm from './components/temp';

const App = () => {
  return (
    <div className="app-container d-flex align-items-center justify-content-center">
      <LoginForm />
    </div>
  );
};

export default App;
